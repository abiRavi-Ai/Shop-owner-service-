export interface ShopOwner {
    id?:number;
    name:string;
    shopName:string;
    contactNumber:string;
    email:string;
    

}
